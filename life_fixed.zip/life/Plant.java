package life;

/** Растение: неподвижно, накапливает энергию и распространяется на соседние клетки. */
public class Plant extends Agent {

    public Plant(int x, int y) {
        super(x, y, Params.PLANT_START_ENERGY);
    }

    @Override
    public void act(Environment env) {
        energy++; // фотосинтез
        if (energy >= Params.PLANT_REPRODUCE_ENERGY) {
            int[] cell = env.randomEmptyNeighbor(x, y);
            if (cell != null) {
                energy -= Params.PLANT_REPRODUCE_ENERGY / 2;
                env.addNew(new Plant(cell[0], cell[1]));
            }
        }
    }

    @Override
    public char symbol() { return '*'; }
}
