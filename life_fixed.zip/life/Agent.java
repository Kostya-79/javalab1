package life;

/** Базовый класс логического агента. */
public abstract class Agent {
    protected int x, y;
    protected int energy;
    protected boolean alive = true;

    protected Agent(int x, int y, int energy) {
        this.x = x;
        this.y = y;
        this.energy = energy;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getEnergy() { return energy; }
    public boolean isAlive() { return alive; }

    /** Исчезновение агента (гибель или съедение). */
    public void die(Environment env) {
        alive = false;
        env.remove(this);
    }

    /** Один шаг поведения агента. */
    public abstract void act(Environment env);

    /** Символ для консольного вывода. */
    public abstract char symbol();
}
