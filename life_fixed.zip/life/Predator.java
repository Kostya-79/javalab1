package life;

/** Хищник: охотится на травоядных. */
public class Predator extends Animal {

    public Predator(int x, int y, int energy) { super(x, y, energy); }

    @Override protected boolean isFood(Agent a) { return a instanceof Herbivore; }
    @Override protected boolean isDanger(Agent a) { return false; }
    @Override protected int energyLoss() { return Params.PRED_ENERGY_LOSS; }
    @Override protected int gain() { return Params.PRED_GAIN; }
    @Override protected int reproduceEnergy() { return Params.PRED_REPRODUCE_ENERGY; }
    @Override protected Animal newChild(int x, int y, int e) { return new Predator(x, y, e); }
    @Override public char symbol() { return 'P'; }
}
