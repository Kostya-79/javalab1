package life;

import javax.swing.*;
import java.awt.*;

/** Окончательный вариант: оконное приложение (Swing). */
public class LifeWindow extends JFrame {
    private static final int CELL = 14;

    private Environment env;
    private final SimPanel simPanel = new SimPanel();
    private final JLabel status = new JLabel(" ");
    private final Timer timer;
    private final JButton startBtn = new JButton("Старт");

    public LifeWindow() {
        super("Искусственная жизнь");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        reset();

        timer = new Timer(60, e -> doStep());

        JButton stepBtn = new JButton("Шаг");
        JButton resetBtn = new JButton("Сброс");
        JSlider speed = new JSlider(1, 100, 40);
        speed.setToolTipText("Скорость");
        startBtn.addActionListener(e -> toggle());
        stepBtn.addActionListener(e -> { stop(); doStep(); });
        resetBtn.addActionListener(e -> { stop(); reset(); repaint(); });
        speed.addChangeListener(e -> timer.setDelay(Math.max(1, 210 - speed.getValue() * 2)));

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controls.add(startBtn);
        controls.add(stepBtn);
        controls.add(resetBtn);
        controls.add(new JLabel("Скорость:"));
        controls.add(speed);

        add(controls, BorderLayout.NORTH);
        add(simPanel, BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void reset() {
        env = new Environment(Params.WIDTH, Params.HEIGHT);
        env.populate();
        record();
    }

    private void toggle() {
        if (timer.isRunning()) stop(); else { timer.start(); startBtn.setText("Пауза"); }
    }

    private void stop() {
        timer.stop();
        startBtn.setText("Старт");
    }

    private void doStep() {
        env.step();
        record();
        if (!env.lifeExists()) {
            stop();
            JOptionPane.showMessageDialog(this, "Жизнь прекратилась на шаге " + env.getStepCount());
        }
        repaint();
    }

    private void record() {
        status.setText(String.format("  Шаг %d | растения: %d | травоядные: %d | хищники: %d",
                env.getStepCount(), env.count(Plant.class),
                env.count(Herbivore.class), env.count(Predator.class)));
    }

    private class SimPanel extends JPanel {
        SimPanel() { setPreferredSize(new Dimension(Params.WIDTH * CELL, Params.HEIGHT * CELL)); }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(new Color(245, 240, 225));
            g.fillRect(0, 0, getWidth(), getHeight());
            for (Agent a : env.getAgents()) {
                if (!a.isAlive()) continue;
                int px = a.getX() * CELL, py = a.getY() * CELL;
                if (a instanceof Plant) {
                    g.setColor(new Color(60, 160, 60));
                    g.fillRect(px + 3, py + 3, CELL - 6, CELL - 6);
                } else if (a instanceof Herbivore) {
                    g.setColor(new Color(30, 110, 220));
                    g.fillOval(px + 1, py + 1, CELL - 2, CELL - 2);
                } else {
                    g.setColor(new Color(210, 30, 30));
                    g.fillPolygon(new int[]{px + CELL / 2, px + 1, px + CELL - 1},
                                  new int[]{py + 1, py + CELL - 1, py + CELL - 1}, 3);
                }
            }
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LifeWindow().setVisible(true));
    }
}
