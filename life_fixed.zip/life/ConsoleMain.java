package life;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

/** Предварительный вариант: консольное приложение. Аргументы: [шагов] [задержка_мс] */
public class ConsoleMain {

    // ANSI-цвета
    private static final String RESET  = "\033[0m";
    private static final String GREEN  = "\033[92m"; // растения
    private static final String YELLOW = "\033[93m"; // травоядные
    private static final String RED    = "\033[91m"; // хищники
    private static final String GRAY   = "\033[90m"; // пустые клетки
    private static final String CYAN   = "\033[96m"; // заголовки

    public static void main(String[] args) throws InterruptedException {
        // вывод в UTF-8, чтобы русские буквы не превращались в «ромбики»
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));

        int steps = args.length > 0 ? Integer.parseInt(args[0]) : 500;
        int delay = args.length > 1 ? Integer.parseInt(args[1]) : 100;

        Environment env = new Environment(Params.WIDTH, Params.HEIGHT);
        env.populate();

        for (int i = 0; i < steps; i++) {
            print(env);
            if (!env.lifeExists()) {
                System.out.println(RED + "Жизнь прекратилась на шаге " + env.getStepCount() + RESET);
                return;
            }
            env.step();
            if (delay > 0) Thread.sleep(delay);
        }
        System.out.println(GREEN + "Моделирование завершено: жизнь не прекратилась." + RESET);
    }

    static String colorOf(Agent a) {
        if (a == null) return GRAY;
        if (a instanceof Plant) return GREEN;
        if (a instanceof Herbivore) return YELLOW;
        return RED;
    }

    static void print(Environment env) {
        StringBuilder sb = new StringBuilder();
        sb.append("\033[H\033[2J"); // очистка консоли (ANSI): курсор в начало и стирание экрана
        for (int y = 0; y < env.getHeight(); y++) {
            for (int x = 0; x < env.getWidth(); x++) {
                Agent a = env.get(x, y);
                sb.append(colorOf(a)).append(a == null ? '.' : a.symbol()).append(' ');
            }
            sb.append(RESET).append('\n');
        }
        sb.append(CYAN).append("Шаг ").append(env.getStepCount()).append(RESET)
          .append(" | ").append(GREEN).append("растения (*): ").append(env.count(Plant.class)).append(RESET)
          .append(" | ").append(YELLOW).append("травоядные (H): ").append(env.count(Herbivore.class)).append(RESET)
          .append(" | ").append(RED).append("хищники (P): ").append(env.count(Predator.class)).append(RESET)
          .append('\n');
        System.out.print(sb);
        System.out.flush();
    }
}
