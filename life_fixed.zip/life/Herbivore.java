package life;

/** Травоядное: ест растения, убегает от хищников. */
public class Herbivore extends Animal {

    public Herbivore(int x, int y, int energy) { super(x, y, energy); }

    @Override protected boolean isFood(Agent a) { return a instanceof Plant; }
    @Override protected boolean isDanger(Agent a) { return a instanceof Predator; }
    @Override protected int energyLoss() { return Params.HERB_ENERGY_LOSS; }
    @Override protected int gain() { return Params.HERB_GAIN; }
    @Override protected int reproduceEnergy() { return Params.HERB_REPRODUCE_ENERGY; }
    @Override protected Animal newChild(int x, int y, int e) { return new Herbivore(x, y, e); }
    @Override public char symbol() { return 'H'; }
}
