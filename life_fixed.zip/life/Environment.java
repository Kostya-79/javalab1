package life;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Окружающая среда: двумерный массив ячеек (в ячейке один агент или пусто). */
public class Environment {
    private final int width, height;
    private final Agent[][] grid;
    private final List<Agent> agents = new ArrayList<>();
    private final List<Agent> born = new ArrayList<>();
    private final Random rnd;
    private int stepCount = 0;

    public Environment(int width, int height) { this(width, height, new Random().nextLong()); }

    /** Конструктор с зерном генератора (для воспроизводимых экспериментов). */
    public Environment(int width, int height, long seed) {
        this.rnd = new Random(seed);
        this.width = width;
        this.height = height;
        this.grid = new Agent[width][height];
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getStepCount() { return stepCount; }
    public List<Agent> getAgents() { return agents; }

    public boolean inside(int x, int y) { return x >= 0 && y >= 0 && x < width && y < height; }

    public Agent get(int x, int y) { return inside(x, y) ? grid[x][y] : null; }

    public boolean isEmpty(int x, int y) { return inside(x, y) && grid[x][y] == null; }

    /** Начальное заселение: размещает агента, если клетка свободна. */
    public boolean place(Agent a) {
        if (!isEmpty(a.x, a.y)) return false;
        grid[a.x][a.y] = a;
        agents.add(a);
        return true;
    }

    /** Новый агент, появившийся во время шага (добавится в конце шага). */
    public void addNew(Agent a) {
        if (!isEmpty(a.x, a.y)) return;
        grid[a.x][a.y] = a;
        born.add(a);
    }

    public void move(Agent a, int nx, int ny) {
        if (!isEmpty(nx, ny)) return;
        grid[a.x][a.y] = null;
        a.x = nx;
        a.y = ny;
        grid[nx][ny] = a;
    }

    public void remove(Agent a) {
        if (grid[a.x][a.y] == a) grid[a.x][a.y] = null;
    }

    /** Свободные соседние клетки: только вверх, вниз, влево, вправо (без диагоналей). */
    public List<int[]> emptyNeighbors(int x, int y) {
        List<int[]> res = new ArrayList<>(4);
        int[][] dirs = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
        for (int[] d : dirs)
            if (isEmpty(x + d[0], y + d[1]))
                res.add(new int[]{x + d[0], y + d[1]});
        return res;
    }

    /** Свободные клетки для хода: только по вертикали и горизонтали (без диагоналей). */
    public List<int[]> emptyStepCells(int x, int y) {
        List<int[]> res = new ArrayList<>(4);
        int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] v : d)
            if (isEmpty(x + v[0], y + v[1])) res.add(new int[]{x + v[0], y + v[1]});
        return res;
    }

    public int[] randomEmptyStep(int x, int y) {
        List<int[]> l = emptyStepCells(x, y);
        return l.isEmpty() ? null : l.get(rnd.nextInt(l.size()));
    }

    public int nextInt(int n) { return rnd.nextInt(n); }

    public int[] randomEmptyNeighbor(int x, int y) {
        List<int[]> l = emptyNeighbors(x, y);
        return l.isEmpty() ? null : l.get(rnd.nextInt(l.size()));
    }

    /** Заполнение среды случайным образом. */
    public void populate() {
        spawn(Params.INITIAL_PLANTS, 0);
        spawn(Params.INITIAL_HERBIVORES, 1);
        spawn(Params.INITIAL_PREDATORS, 2);
    }

    private void spawn(int n, int type) {
        int placed = 0, tries = 0;
        while (placed < n && tries++ < n * 50) {
            int x = rnd.nextInt(width), y = rnd.nextInt(height);
            Agent a;
            switch (type) {
                case 0:  a = new Plant(x, y); break;
                case 1:  a = new Herbivore(x, y, Params.HERB_START_ENERGY); break;
                default: a = new Predator(x, y, Params.PRED_START_ENERGY); break;
            }
            if (place(a)) placed++;
        }
    }

    /** Один шаг игры. */
    public void step() {
        List<Agent> order = new ArrayList<>(agents);
        Collections.shuffle(order, rnd);
        for (Agent a : order) {
            if (a.isAlive()) a.act(this);
        }
        for (int i = 0; i < Params.PLANT_SEEDS_PER_STEP; i++) { // случайное прорастание
            int x = rnd.nextInt(width), y = rnd.nextInt(height);
            if (isEmpty(x, y)) addNew(new Plant(x, y));
        }
        agents.removeIf(a -> !a.isAlive());
        agents.addAll(born);
        born.clear();
        stepCount++;
    }

    public int count(Class<? extends Agent> c) {
        int n = 0;
        for (Agent a : agents) if (c.isInstance(a) && a.isAlive()) n++;
        return n;
    }

    /** Жизнь продолжается, пока есть хотя бы одно животное. */
    public boolean lifeExists() {
        return count(Herbivore.class) + count(Predator.class) > 0;
    }
}
