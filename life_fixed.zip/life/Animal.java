package life;

/**
 * Подвижный агент со зрением 5x5. Поведение задаётся логическими выражениями:
 *  1) если опасность близко (в пределах FLEE_RADIUS) — бежать;
 *  2) иначе если еда в соседней клетке — съесть;
 *  3) иначе если еда видна — идти к ней;
 *  4) иначе — целенаправленный поиск еды (движение по курсу, без хаотичных блужданий).
 * Затем: размножение при превышении порога энергии.
 *
 * Животное не бывает «сытым»: поев, оно сразу продолжает искать и есть дальше.
 * Численность растёт только за счёт размножения (миграции нет).
 */
public abstract class Animal extends Agent {

    private static final int[][] DIRS = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

    /** Текущий курс поиска еды (индекс в DIRS). */
    private int heading = -1;

    protected Animal(int x, int y, int energy) {
        super(x, y, energy);
    }

    protected abstract boolean isFood(Agent a);
    protected abstract boolean isDanger(Agent a);
    protected abstract int energyLoss();
    protected abstract int gain();
    protected abstract int reproduceEnergy();
    protected abstract Animal newChild(int x, int y, int energy);

    @Override
    public void act(Environment env) {
        // Расход энергии и гибель
        energy -= energyLoss();
        if (energy <= 0) {
            die(env);
            return;
        }

        // Зрение: ближайшие еда и опасность в области 5x5
        Agent food = null, danger = null;
        int foodDist = Integer.MAX_VALUE, dangerDist = Integer.MAX_VALUE;
        for (int dx = -Params.VISION; dx <= Params.VISION; dx++) {
            for (int dy = -Params.VISION; dy <= Params.VISION; dy++) {
                if (dx == 0 && dy == 0) continue;
                Agent a = env.get(x + dx, y + dy);
                if (a == null || !a.isAlive()) continue;
                int d = dx * dx + dy * dy;
                if (isFood(a) && d < foodDist) { food = a; foodDist = d; }
                if (isDanger(a) && d <= Params.FLEE_RADIUS_SQ && d < dangerDist) { danger = a; dangerDist = d; }
            }
        }

        boolean dangerVisible = danger != null;
        boolean foodAdjacent = food != null && foodDist <= 1; // соседняя клетка (без диагоналей)
        boolean foodVisible = food != null;

        if (dangerVisible) {
            fleeFrom(env, danger);
        } else if (foodAdjacent) {
            eat(env, food);
        } else if (foodVisible) {
            moveToward(env, food.getX(), food.getY());
        } else {
            search(env);
        }

        if (alive) reproduce(env);
    }

    /** Поедание: еда исчезает, агент занимает её клетку. */
    protected void eat(Environment env, Agent food) {
        int fx = food.getX(), fy = food.getY();
        food.die(env);
        env.move(this, fx, fy);
        energy += gain();
    }

    /**
     * Целенаправленный поиск еды: агент держит курс, пока путь свободен,
     * и лишь изредка (или упёршись в препятствие) выбирает новое направление.
     */
    protected void search(Environment env) {
        if (heading < 0 || env.nextInt(100) < Params.TURN_CHANCE) {
            heading = env.nextInt(4);
        }
        for (int i = 0; i < 4; i++) {
            int[] d = DIRS[heading];
            int nx = x + d[0], ny = y + d[1];
            if (env.isEmpty(nx, ny)) {
                env.move(this, nx, ny);
                return;
            }
            heading = env.nextInt(4); // упёрлись — новый курс
        }
    }

    protected void moveToward(Environment env, int tx, int ty) {
        int[] best = null;
        int bestD = (tx - x) * (tx - x) + (ty - y) * (ty - y);
        for (int[] c : env.emptyStepCells(x, y)) {
            int d = (tx - c[0]) * (tx - c[0]) + (ty - c[1]) * (ty - c[1]);
            if (d < bestD) { bestD = d; best = c; }
        }
        if (best != null) env.move(this, best[0], best[1]);
    }

    protected void fleeFrom(Environment env, Agent enemy) {
        int[] best = null;
        int bestD = (enemy.getX() - x) * (enemy.getX() - x) + (enemy.getY() - y) * (enemy.getY() - y);
        for (int[] c : env.emptyStepCells(x, y)) {
            int d = (enemy.getX() - c[0]) * (enemy.getX() - c[0]) + (enemy.getY() - c[1]) * (enemy.getY() - c[1]);
            if (d > bestD) { bestD = d; best = c; }
        }
        if (best != null) env.move(this, best[0], best[1]);
    }

    /** Появление: потомок забирает половину энергии родителя. */
    protected void reproduce(Environment env) {
        if (energy < reproduceEnergy()) return;
        int[] c = env.randomEmptyNeighbor(x, y);
        if (c == null) return;
        int childEnergy = energy / 2;
        energy -= childEnergy;
        env.addNew(newChild(c[0], c[1], childEnergy));
    }
}
