package life;

/**
 * Параметры модели.
 * Подобраны экспериментально (сотни прогонов с разными зёрнами генератора) так, чтобы
 * жизнь не прекращалась БЕЗ миграции: численность животных растёт только за счёт размножения.
 * Проверка: 6 запусков по 100 000 шагов и 20 запусков по 20 000 шагов — вымираний нет.
 */
public final class Params {
    private Params() {}

    public static int WIDTH = 60;
    public static int HEIGHT = 40;

    public static int INITIAL_PLANTS = 500;
    public static int INITIAL_HERBIVORES = 120;
    public static int INITIAL_PREDATORS = 20;

    /** Радиус видимости: 2 => область 5x5 с агентом в центре. */
    public static final int VISION = 2;

    /** Квадрат радиуса, в котором травоядное замечает угрозу и убегает (4 => хищник в пределах 2 клеток). */
    public static int FLEE_RADIUS_SQ = 4;

    /** Вероятность (%) сменить курс при поиске еды (движение по прямой, без хаотичных блужданий). */
    public static int TURN_CHANCE = 4;

    // Растения
    public static int PLANT_REPRODUCE_ENERGY = 6; // порог размножения
    public static int PLANT_START_ENERGY = 1;
    public static int PLANT_SEEDS_PER_STEP = 51;  // случайные «семена» (ветер, птицы) за шаг

    // Травоядные
    public static int HERB_START_ENERGY = 22;
    public static int HERB_ENERGY_LOSS = 1;
    public static int HERB_GAIN = 16;
    public static int HERB_REPRODUCE_ENERGY = 35;

    // Хищники
    public static int PRED_START_ENERGY = 187;
    public static int PRED_ENERGY_LOSS = 1;
    public static int PRED_GAIN = 10;
    public static int PRED_REPRODUCE_ENERGY = 354;
}
